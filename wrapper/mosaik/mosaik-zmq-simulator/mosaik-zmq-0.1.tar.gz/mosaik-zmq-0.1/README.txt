mosaik-zmq
===========

Sends mosaik simulation data to a ZeroMQ socket.


Installation
------------

::

    $ pip install mosaik-zmq

Examples
--------

::

Odysseus...
	* Datenreduktion
	* Echtzeit-Verarbeitung